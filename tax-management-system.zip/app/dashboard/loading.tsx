import { PageLoader } from "@/components/ui/page-loader"

export default function DashboardLoading() {
  return <PageLoader />
}
